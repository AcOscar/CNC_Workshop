﻿Imports Rhino
Imports Rhino.DocObjects
Imports Rhino.Geometry
Imports Rhino.Input
Imports Rhino.Input.Custom

Public Class RhWorker

    Const ToolKey As String = "hdm_tool"

    Protected Friend Optimizer As New OptimizerByIndex

    Private _hidedObj As New List(Of RhinoObject)

    Property LengtLabel As Label

    Property PB_FileUpload As ProgressBar

    Property PB_JobProcess As ProgressBar

    Private Property PreSelectedObj As Boolean

    ''' <summary>
    ''' pure time to cut objects without anything else
    ''' </summary>
    ''' <remarks></remarks>
    Private WorkTime As New TimeSpan

    ''' <summary>
    ''' converts a RhinoObject to a GeometryObject
    ''' </summary>
    ''' <param name="rhObj">the rhino object</param>
    ''' <param name="ZeroPoint">the zeropoint of the bench</param>
    Public Function RhToToolGeom(ByVal rhObj As RhinoObject, ByVal ZeroPoint As Coordinate) As GeometryObject

        Dim myObj As GeometryObject = Nothing

        Select Case rhObj.ObjectType
            ' Point
            Case Rhino.DocObjects.ObjectType.Point
                ' RhinoApp.WriteLine("found a point")

                Dim myPoint As DocObjects.PointObject = CType(rhObj, PointObject)

                Dim Point As New Coordinate(myPoint.PointGeometry.Location.X - ZeroPoint.X, myPoint.PointGeometry.Location.Y - ZeroPoint.Y)

                myObj = Point

            Case Rhino.DocObjects.ObjectType.Curve

                Dim myCurve As DocObjects.CurveObject = CType(rhObj, CurveObject)

                Select Case myCurve.CurveGeometry.GetType

                    Case GetType(ArcCurve)
                        'RhinoApp.WriteLine("found a ArcCurve")
                        'todo kreis ist irgendwie noch  mist
                        Dim myArc As ArcCurve = CType(myCurve.Geometry, ArcCurve)

                        If myArc.IsCompleteCircle Then

                            Dim mycncArc As New Arc

                            mycncArc.Center = New Coordinate(myArc.Arc.Center.X - ZeroPoint.X, myArc.Arc.Center.Y - ZeroPoint.Y)

                            mycncArc.Radius = myArc.Arc.Radius

                            myObj = mycncArc

                        Else

                            Dim myPoint As New Coordinate(myArc.PointAtStart.X, myArc.PointAtStart.Y)

                            Dim mypline As New PolyLine

                            mypline.Points.Add(CType(myPoint - ZeroPoint, Coordinate))

                            mypline.Points.AddRange(PointsFromArc(myArc, ZeroPoint))

                            myObj = mypline

                        End If

                    Case GetType(NurbsCurve)

                        Dim myNurbsCurve As NurbsCurve = CType(myCurve.Geometry, NurbsCurve)

                        Dim myPoint As New Coordinate(myNurbsCurve.PointAtStart.X, myNurbsCurve.PointAtStart.Y)

                        Dim mypline As New PolyLine

                        mypline.Points.Add(CType(myPoint - ZeroPoint, Coordinate))

                        mypline.Points.AddRange(PointsFromNurbs(myNurbsCurve, ZeroPoint))

                        myObj = mypline

                    Case GetType(PolylineCurve)

                        Dim myPolylineCurve As PolylineCurve = CType(myCurve.Geometry, PolylineCurve)

                        Dim myPoint As New Coordinate(myPolylineCurve.Point(0).X, myPolylineCurve.Point(0).Y)

                        Dim mypline As New PolyLine

                        mypline.Points.Add(CType(myPoint - ZeroPoint, Coordinate))

                        mypline.Points.AddRange(PointsFromPolyline(myPolylineCurve, ZeroPoint))

                        myObj = mypline

                    Case GetType(PolyCurve)

                        Dim myPoint As New Coordinate

                        Dim PlCrv As PolyCurve = CType(myCurve.CurveGeometry, PolyCurve)

                        myPoint = New Coordinate(PlCrv.PointAtStart.X, PlCrv.PointAtStart.Y)

                        Dim mypline As New PolyLine

                        mypline.Points.Add(CType(myPoint - ZeroPoint, Coordinate))

                        For i = 0 To PlCrv.SegmentCount - 1

                            Dim mySegment As Curve = PlCrv.SegmentCurve(i)

                            Select Case mySegment.GetType

                                Case GetType(NurbsCurve)

                                    mypline.Points.AddRange(PointsFromNurbs(CType(mySegment, NurbsCurve), ZeroPoint))

                                Case GetType(LineCurve)

                                    mypline.Points.AddRange(PointsFromLine(CType(mySegment, LineCurve), ZeroPoint))

                                Case GetType(ArcCurve)

                                    mypline.Points.AddRange(PointsFromArc(CType(mySegment, ArcCurve), ZeroPoint))

                                Case GetType(PolylineCurve)

                                    mypline.Points.AddRange(PointsFromPolyline(CType(mySegment, PolylineCurve), ZeroPoint))
#If DEBUG Then
                                Case Else

                                    Stop
#End If
                            End Select

                        Next

                        myObj = mypline

                    Case GetType(LineCurve)

                        Dim LCrv As LineCurve = CType(myCurve.CurveGeometry, LineCurve)

                        Dim myPoint As New Coordinate

                        myPoint = New Coordinate(LCrv.PointAtStart.X - ZeroPoint.X, LCrv.PointAtStart.Y - ZeroPoint.Y)

                        Dim mypline As New PolyLine

                        mypline.Points.Add(myPoint)

                        mypline.Points.AddRange(PointsFromLine(LCrv, ZeroPoint))

                        myObj = mypline

                    Case Else
                        '  RhinoApp.WriteLine("found object which can not be plotted :" & myCurve.CurveGeometry.GetType.ToString)

                End Select

            Case Else

                ' RhinoApp.WriteLine("found object which can not be plotted :" & rhObj.ObjectType.ToString)

        End Select
        ' Next

        If myObj IsNot Nothing Then

            myObj.RhinoOriginalID = rhObj.Id

        End If

        Return myObj

    End Function

    Friend Sub CellEvent(ByRef LayerGrid As System.Windows.Forms.DataGridView, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

        Dim ColNo As Integer = e.ColumnIndex

        Dim RowNo As Integer = e.RowIndex

        Dim ToolName As String = LayerGrid.Rows(RowNo).Cells(ColNo).Value.ToString

        Dim LayerName As String = LayerGrid.Rows(RowNo).Cells(0).Value.ToString

        Select Case (ColNo)
            Case 1

                If ToolName <> "" Then

                    Dim doc As RhinoDoc

                    doc = Rhino.RhinoDoc.ActiveDoc

                    Dim layer_table As Tables.LayerTable = doc.Layers

                    Dim layer_index As Integer = layer_table.Find(LayerName.TrimStart, True)

                    layer_table(layer_index).SetUserString(ToolKey, ToolName)

                End If

        End Select

        For Each r As DataGridViewRow In LayerGrid.Rows

            r.Cells(1).ToolTipText = ToolTipText(r.Cells(1).Value.ToString)

        Next

    End Sub

    Public Sub RefreshLayerList(ByRef LayerGrid As System.Windows.Forms.DataGridView, ByVal ShowHiddenLayer As Boolean)

        LayerGrid.Rows.Clear()

        Dim layer_table As Tables.LayerTable = RhinoDoc.ActiveDoc.Layers

        If layer_table.ActiveCount = 0 Then

            Exit Sub

        End If

        LayerGrid.Rows.Add(layer_table.ActiveCount)

        For Each l As Layer In layer_table

            If Not l.IsDeleted Then

                Dim userdata As String = String.Empty

                userdata = l.GetUserString(ToolKey)

                Dim n As Integer

                Dim LayerName As String = String.Empty

                n = l.SortIndex

                If l.ParentLayerId <> Guid.Empty Then

                    LayerName = "    "

                End If

                LayerName &= l.Name

                'beim Purgen kann das vorkommen
                If LayerGrid.Rows.Count > n Then

                    LayerGrid.Rows(n).Cells(0).Value = LayerName


                    If userdata = String.Empty Then

                        LayerGrid.Rows(n).Cells(1).Value = "-"

                    Else

                        LayerGrid.Rows(n).Cells(1).Value = userdata

                        LayerGrid.Rows(n).Cells(1).ToolTipText = ToolTipText(userdata)

                    End If

                End If

            End If

        Next

        If ShowHiddenLayer Then

            Dim myL As New List(Of DataGridViewRow)

            For Each row As DataGridViewRow In LayerGrid.Rows

                If row.Cells(1).Value.ToString = "-" Then

                    myL.Add(row)

                End If

            Next

            For Each r As DataGridViewRow In myL

                LayerGrid.Rows.Remove(r)

            Next

        End If

    End Sub

    Private Function ToolTipText(ByVal Key As String) As String

        Select Case Key

            Case "SP1"

                Return "a fast cutting tool"

            Case "SP2"

                Return "a slow but precisely cutting tool"

            Case "SP4"

                Return "a pen to draw on the material"

            Case "CUT"

                Return "for laser cut"

            Case "ENG"

                Return "for laser engraving"

            Case Else

                Return "no tool selected"

        End Select

        Return Key

    End Function

    Private Function PointsFromPolyline(ByVal Polyline As PolylineCurve, ByVal ZeroPoint As Coordinate) As List(Of Coordinate)

        Dim myPoints As New List(Of Coordinate)

        For i = 1 To Polyline.PointCount - 1

            myPoints.Add(New Coordinate(Polyline.Point(i).X - ZeroPoint.X, Polyline.Point(i).Y - ZeroPoint.Y))

        Next

        Return myPoints

    End Function

    Private Function PointsFromLine(ByVal Line As LineCurve, ByVal ZeroPoint As Coordinate) As List(Of Coordinate)

        Dim myPoints As New List(Of Coordinate)

        myPoints.Add(New Coordinate(Line.PointAtEnd.X - ZeroPoint.X, Line.PointAtEnd.Y - ZeroPoint.Y))

        Return myPoints

    End Function

    Private Function PointsFromArc(ByVal Arc As ArcCurve, ByVal ZeroPoint As Coordinate) As List(Of Coordinate)

        Dim myPoints As List(Of Coordinate)

        Dim Points() As Point3d = Nothing

        Arc.DivideByLength(1, True, Points)

        myPoints = AsList(Points)

        myPoints.RemoveAt(0)

        For i As Integer = 0 To myPoints.Count - 1

            myPoints(i) = CType(myPoints(i) - ZeroPoint, Coordinate)

        Next

        Return (myPoints)

    End Function

    Private Function PointsFromNurbs(ByVal Nurbs As NurbsCurve, ByVal ZeroPoint As Coordinate) As List(Of Coordinate)

        Dim myPoints As List(Of Coordinate)

        Dim Points() As Point3d = Nothing

        Nurbs.DivideByLength(1, False, Points)

        myPoints = AsList(Points)

        For i As Integer = 0 To myPoints.Count - 1

            myPoints(i) = CType(myPoints(i) - ZeroPoint, Coordinate)

        Next

        Return myPoints

    End Function

    Private Function AsList(ByVal Points() As Point3d) As List(Of Coordinate)

        Dim myPoints As New List(Of Coordinate)

        If Points IsNot Nothing Then

            For Each p As Point3d In Points

                myPoints.Add(New Coordinate(p.X, p.Y))

            Next

        End If

        Return myPoints

    End Function

    Sub BBoxOn(ByVal Device As CNC_Device, ByVal Conduit As rhDisplayConduit, ByVal offset As Decimal)

        Device.BBoxTool.CreateBBox(offset)

        Device.withBBox = True

        Conduit.BoundingPoints = New Rhino.Collections.RhinoList(Of Geometry.Point3d)

        For Each g As GeometryObject In Device.BBoxTool.BBox
            Dim myPoint As New Coordinate(g.FirstPoint)

            'allowed range
            If myPoint.X < 0 Then myPoint = New Coordinate(0, myPoint.Y)
            If myPoint.Y < 0 Then myPoint = New Coordinate(myPoint.X, 0)

            If myPoint.X > Device.Work.X Then myPoint = New Coordinate(Device.Work.X, myPoint.Y)
            If myPoint.Y > Device.Work.Y Then myPoint = New Coordinate(myPoint.X, Device.Work.Y)

            Conduit.BoundingPoints.Add(New Point3d(myPoint.X + Conduit.ZeroPoint.X, myPoint.Y + Conduit.ZeroPoint.Y, 0))

        Next

        'to close the polyline
        Conduit.BoundingPoints.Add(Conduit.BoundingPoints(0))

    End Sub

    Sub BBoxOff(ByVal Device As CNC_Device, ByVal DispConduit As rhDisplayConduit)

        Device.withBBox = False

        DispConduit.BoundingPoints = Nothing

    End Sub

    Public Sub Compatility()

        Dim myDoc As RhinoDoc = RhinoDoc.ActiveDoc

        Dim frame_RhObj_list As New List(Of RhinoObject)

        Dim myFilter As New Rhino.DocObjects.ObjectEnumeratorSettings

        myFilter.ObjectTypeFilter = ObjectType.Point Or ObjectType.Curve

        For Each myLayer As Rhino.DocObjects.Layer In myDoc.Layers

            If myLayer.IsDeleted Then

                Resume Next

            End If

            Select Case myLayer.Name.ToLower

                Case "932_frame"
                    '    myLayer.SetUserString(ToolKey, "frame")

                Case "932_engrave"
                    myLayer.SetUserString(ToolKey, "ENG")

                Case "932_cut"
                    myLayer.SetUserString(ToolKey, "CUT")

                Case "932_sp1"
                    myLayer.SetUserString(ToolKey, "SP1")

                Case "932_sp2"
                    myLayer.SetUserString(ToolKey, "SP2")

                Case "932_sp4"
                    myLayer.SetUserString(ToolKey, "SP4")

            End Select

        Next

    End Sub

    Function GetConduitObj(ByVal ProxyList As List(Of GeometryObject)) As Rhino.Collections.RhinoList(Of Curve)

        Dim myRhobj As New Rhino.Collections.RhinoList(Of Curve)

        For Each obj As GeometryObject In ProxyList

            Select Case obj.GetType

                Case GetType(Line)

                    Dim myProxyLine As Line = CType(obj, Line)

                    Dim myLineGeom As New Rhino.Geometry.Line(myProxyLine.X1, myProxyLine.Y1, 0, myProxyLine.X2, myProxyLine.Y2, 0)

                    myRhobj.Add(myLineGeom.ToNurbsCurve)

            End Select

        Next

        Return myRhobj

    End Function

    Function newZero(ByVal Device As CNC_Device, ByRef DispConduit As rhDisplayConduit) As Boolean

        DispConduit.MoveOffset = New Point3d

        DispConduit.DrawTraceLine = False

        DispConduit.StartMoving()

        Dim gp = New Rhino.Input.Custom.GetPoint()

        gp.SetCommandPrompt("Point to move from")

        gp.Get()

        If gp.CommandResult() <> Rhino.Commands.Result.Success Then

            DispConduit.EndMoving()

            Return False

        End If

        DispConduit.MoveOffset = CType(gp.Point - DispConduit.ZeroPoint, Point3d)

        DispConduit.MoveFrom = gp.Point

        DispConduit.DrawTraceLine = True

        Dim myFeedback As New MouseFeedBack With {.Conduit = DispConduit, .Enabled = True}

        gp = New Rhino.Input.Custom.GetPoint()

        gp.SetCommandPrompt("Point to move to")

        gp.Get()

        myFeedback.Enabled = False

        If gp.CommandResult() <> Rhino.Commands.Result.Success Then

            DispConduit.EndMoving()

            Return False

        End If

        Dim _newZero As New Coordinate(gp.Point.X - DispConduit.MoveOffset.X, gp.Point.Y - DispConduit.MoveOffset.Y)

        If Device.ZeroPoint = _newZero Then

            DispConduit.EndMoving()

            Return False

        End If

        Device.ZeroPoint = _newZero

        DispConduit.ZeroPoint = CType(gp.Point - DispConduit.MoveOffset, Point3d)

        DispConduit.EndMoving()

        Return True

    End Function


#Region "Process"

    Private FutureObjects As New List(Of RhinoObject)

    '  Private HistoryObjects As New List(Of RhinoObject)

    Private CurrentObject As RhinoObject

    Private _IdToFind As System.Guid

    Private nrObj As Integer

    Sub ProcessWholeBench(ByVal Device As CNC_Device, ByVal Conduit As rhDisplayConduit, ByVal PreviewWasOn As Boolean)

        Conduit.Purge()

        If Not PreviewWasOn Then

            PurgeOldObjectsFromTools(Device)

            CollectingObjects(Device)

            Optimizer.OptimizePathes(Device)

        End If

        nrObj = DisplayAllObjByTool(Device, Conduit)

        PB_FileUpload.Maximum = nrObj

        PB_JobProcess.Maximum = nrObj

        PB_FileUpload.Value = 0

        PB_JobProcess.Value = 0

        Device.currentObject = 0 'this will calculate the estimated jobtime

        UpdateLabel(Device, LabelState.Processing)

        If nrObj > 0 Then

            Device.Process()

        End If

    End Sub

    Public Enum LabelState
        Processing
        Estimated
        Finished
        asIs
    End Enum

    Shared myElapsedLength As Double

    Sub UpdateLabel(ByVal Device As CNC_Device, ByVal State As LabelState, Optional ByRef Text As String = "")

        Dim myLabelText As String

        If State = LabelState.Processing AndAlso Device.currentObject = 0 Then
            State = LabelState.Estimated

        End If

        Select Case State

            Case LabelState.Processing

                myElapsedLength += Device.CurTool.Geometry(Device.currentObject).Length

                Dim myElepsMilliSec As Long = CNC_Device.ProcessTimer.ElapsedMilliseconds

                Dim myAvMMpMS As Double = myElapsedLength / myElepsMilliSec

                Dim myTotalTimeMS As Double = Device.WorkingLength / myAvMMpMS

                myTotalTimeMS -= myElepsMilliSec

                Dim myTotaltime As New TimeSpan

                myTotaltime = TimeSpan.FromMilliseconds(myTotalTimeMS)

                myLabelText = String.Format("{0:0}:{1:00}:{2:00}", myTotaltime.Hours, myTotaltime.Minutes, myTotaltime.Seconds)

                If CNC_Device.ProcessTimer.IsRunning Then

                    LengtLabel_Invoker(Device.currentObject & " of " & Device.TotalProcessOrderCount & " objects finished in " & myLabelText)

                End If

            Case LabelState.Estimated

                myLabelText = String.Format("{0:0}:{1:00}:{2:00}", Device.EstimededTime.Hours, Device.EstimededTime.Minutes, Device.EstimededTime.Seconds)

                myLabelText &= vbCrLf & String.Format("{0:0} mm empty", Device.TravelLength)

                myLabelText &= vbCrLf & String.Format("{0:0} mm work", Device.WorkingLength)

                LengtLabel_Invoker(Device.TotalProcessOrderCount & " objects estimated in " & myLabelText)

                myElapsedLength = 0

            Case LabelState.Finished

                myLabelText = String.Format("{0:0}:{1:00}:{2:00}", CNC_Device.ProcessTimer.Elapsed.Hours, CNC_Device.ProcessTimer.Elapsed.Minutes, CNC_Device.ProcessTimer.Elapsed.Seconds)

                LengtLabel_Invoker(Device.TotalProcessOrderCount & " objects processed in " & myLabelText)

                myElapsedLength = 0

            Case LabelState.asIs

                LengtLabel_Invoker(Text)

        End Select

    End Sub

    Sub LengtLabel_Invoker(ByVal Text As String)

        If LengtLabel.InvokeRequired Then

            LengtLabel.Invoke(Sub() LengtLabel_Invoker(Text))

        Else

            LengtLabel.Text = Text

        End If

    End Sub


    ''' <summary>
    ''' deletes all geometry object from all tools
    ''' </summary>
    Private Sub PurgeOldObjectsFromTools(ByVal Device As CNC_Device)

        For Each Tool As CNC_Tool In Device.Tools

            Tool.Geometry = New List(Of GeometryObject)

            Tool.ProcessOrder = New List(Of Integer)

        Next

    End Sub

    ''' <summary>
    ''' fügt alle object hinzu
    ''' </summary>
    Private Sub CollectingObjects(ByVal Device As CNC_Device)

        Dim p1 As Point3d = New Point3d(Device.ZeroPoint.X, Device.ZeroPoint.Y, 0)

        Dim p2 As Point3d = New Point3d(Device.ZeroPoint.X + Device.Work.X, Device.ZeroPoint.Y + Device.Work.Y, 0)

        Dim settings As New Rhino.DocObjects.ObjectEnumeratorSettings()

        settings.ObjectTypeFilter = CType(ObjectType.Curve + ObjectType.Point, ObjectType)

        settings.ActiveObjects = True

        settings.DeletedObjects = False

        settings.HiddenObjects = False

        Dim WorkBBox As BoundingBox = New BoundingBox(p1, p2)

        Dim ToolName As String = String.Empty

        Dim myDoc As RhinoDoc = RhinoDoc.ActiveDoc

        'cycle through all objects
        For Each obj As RhinoObject In myDoc.Objects.GetObjectList(settings)

            Dim myBox As BoundingBox = obj.Geometry.GetBoundingBox(False)

            If WorkBBox.Contains(myBox) Then

                ToolName = myDoc.Layers(obj.Attributes.LayerIndex).GetUserString(ToolKey)

                Dim myToolGeometryObj As GeometryObject = RhToToolGeom(obj, Device.ZeroPoint)

                Device.addPlotObject(ToolName, myToolGeometryObj)

            End If

        Next

    End Sub

    Private Sub HideAllObjects()

        Dim myDoc As RhinoDoc = RhinoDoc.ActiveDoc

        For Each obj As RhinoObject In myDoc.Objects

            If myDoc.Objects.Hide(obj, True) Then

                _hidedObj.Add(obj)

            End If

        Next

    End Sub

    Private Function DisplayAllObjByTool(ByRef Device As CNC_Device, ByVal Conduit As rhDisplayConduit) As Integer
        FutureObjects = New List(Of RhinoObject)

        Conduit.Purge()

        Dim NumberOfObjects = 0

        For Each tool As CNC_Tool In Device.Tools

            If tool.Geometry.Count = 0 Then

                Continue For

            End If

            Dim myDoc As RhinoDoc = RhinoDoc.ActiveDoc

            For Each obj As GeometryObject In tool.OrderedGeometry

                Dim myObj As RhinoObject = myDoc.Objects.Find(obj.RhinoOriginalID)

                If myObj IsNot Nothing Then

                    If TypeOf myObj.Geometry Is Curve Then

                        Dim myCrv As Curve = CType(myObj.Geometry, Curve)

                        If obj.isReverted Then

                            myCrv.Reverse()

                        End If

                        FutureObjects.Add(myObj)

                        Conduit.FutureObjects.Add(myCrv)

                        NumberOfObjects += 1

                    ElseIf TypeOf myObj.Geometry Is Point Then
                        'Condouits.FutureObjects must be a Curve
                        Dim myPoint As Rhino.Geometry.Point = CType(myObj.Geometry, Point)

                        Dim myCrv As New Rhino.Geometry.Line(myPoint.Location, myPoint.Location)

                        FutureObjects.Add(myObj)

                        Conduit.FutureObjects.Add(myCrv.ToNurbsCurve)

                        NumberOfObjects += 1

                    End If

                End If

            Next

        Next

        Return NumberOfObjects

    End Function

    'Private Function GetPolyPoints(ByVal PolyLine As PolyLine) As Rhino.Collections.RhinoList(Of Geometry.Point3d)

    '    Dim myBoundingObjects As New Rhino.Collections.RhinoList(Of Geometry.Point3d)

    '    For Each p As Coordinate In PolyLine.Points

    '        myBoundingObjects.Add(New Rhino.Geometry.Point3d(p.X, p.Y, p.Z))

    '    Next

    '    Return myBoundingObjects

    'End Function

    Private Sub ShowAllObjects()

        Dim myDoc As RhinoDoc = RhinoDoc.ActiveDoc

        For Each obj As RhinoObject In _hidedObj

            myDoc.Objects.Show(obj, True)

        Next

        _hidedObj = New List(Of RhinoObject)

    End Sub

    Sub SwitchObjectsInProgressBegin(ByVal DispConduit As rhDisplayConduit, ByVal Id As Guid)

        _IdToFind = Id

        CurrentObject = FutureObjects.Find(AddressOf findById)

        If CurrentObject Is Nothing Then

            Exit Sub

        End If

        FutureObjects.Remove(CurrentObject)

        DispConduit.FutureObjects.Remove(CType(CurrentObject.Geometry, Curve))


        If TypeOf CurrentObject.Geometry Is Curve Then

            DispConduit.CurrentObject = CType(CurrentObject.Geometry, Curve)

        End If

        'DispConduit.FutureObjects = New Rhino.Collections.RhinoList(Of Geometry.Curve)

        'For Each obj As RhinoObject In FutureObjects

        '    If TypeOf obj.Geometry Is Curve Then

        '        DispConduit.FutureObjects.Add(CType(obj.Geometry, Curve))

        '    End If

        'Next

        RhinoDoc.ActiveDoc.Views.Redraw()

    End Sub

    Sub SwitchObjectsInProgressEnd(ByVal DispConduit As rhDisplayConduit)

        If CurrentObject IsNot Nothing Then

            DispConduit.HistoryObjects.Add(DispConduit.CurrentObject)

        End If

        DispConduit.CurrentObject = Nothing

    End Sub

    Private Function findById(ByVal obj As RhinoObject) As Boolean

        If obj.Id = _IdToFind Then

            Return True

        Else

            Return False

        End If

    End Function

#End Region

    ReadOnly Property isObjectSelected() As Boolean

        Get

            If PreSelectedObj Then

                Return True

            Else

                Return False

            End If

        End Get

    End Property

    Function PreChoosingObjects(ByRef Device As CNC_Device, ByVal Conduit As rhDisplayConduit) As Integer

        PurgeOldObjectsFromTools(Device)

        nrObj = CollectingObjectsByChoosing(Device)

        DisplayAllObjByTool(Device, Conduit)

        HideAllObjects()

        DisplayAllObjByTool(Device, Conduit)

        If nrObj > 0 Then
            PreSelectedObj = True
        Else
            PreSelectedObj = False
        End If

        Return nrObj

    End Function

    Sub ProcessChoosed(ByVal Device As CNC_Device)

        Device.Process()

    End Sub

    Function CollectingObjectsByChoosing(ByRef Device As CNC_Device) As Integer

        Const geometryFilter As ObjectType = ObjectType.Curve Or ObjectType.Point

        Dim go As New GetObject()

        go.SetCommandPrompt("Select objects")

        go.GeometryFilter = geometryFilter

        go.GroupSelect = True

        go.SubObjectSelect = False

        go.EnableClearObjectsOnEntry(False)

        go.EnableUnselectObjectsOnExit(False)

        go.DeselectAllBeforePostSelect = False

        Dim bHavePreselectedObjects As Boolean = False

        While True

            Dim res As GetResult = go.GetMultiple(1, 0)

            If res = GetResult.Option Then
                go.EnablePreSelect(False, True)
                Continue While

            ElseIf res <> GetResult.[Object] Then

                Return 0

            End If

            If go.ObjectsWerePreselected Then

                bHavePreselectedObjects = True

                go.EnablePreSelect(False, True)

                Continue While

            End If

            Exit While
        End While

        If bHavePreselectedObjects Then
            ' Normally, pre-selected objects will remain selected, when a
            ' command finishes, and post-selected objects will be unselected.
            ' This this way of picking, it is possible to have a combination
            ' of pre-selected and post-selected. So, to make sure everything
            ' "looks the same", lets unselect everything before finishing
            ' the command.
            For i As Integer = 0 To go.ObjectCount - 1
                Dim rhinoObject As RhinoObject = go.[Object](i).[Object]()
                If rhinoObject IsNot Nothing Then
                    rhinoObject.[Select](False)
                End If
            Next
            'doc.Views.Redraw()
            RhinoDoc.ActiveDoc.Views.ActiveView.Redraw()
        End If

        Dim objectCount As Integer = go.ObjectCount

        Dim p1 As Point3d = New Point3d(Device.ZeroPoint.X, Device.ZeroPoint.Y, 0)

        Dim p2 As Point3d = New Point3d(Device.ZeroPoint.X + Device.Work.X, Device.ZeroPoint.Y + Device.Work.Y, 0)

        Dim settings As New Rhino.DocObjects.ObjectEnumeratorSettings()

        settings.ObjectTypeFilter = CType(ObjectType.Curve + ObjectType.Point, ObjectType)

        settings.ActiveObjects = True

        settings.DeletedObjects = False

        settings.HiddenObjects = False

        Dim WorkBBox As BoundingBox = New BoundingBox(p1, p2)

        Dim ToolName As String = String.Empty

        Dim myDoc As RhinoDoc = RhinoDoc.ActiveDoc

        'cycle through all objects

        For Each obj As ObjRef In go.Objects

            'Next
            Dim myRhinoObj As RhinoObject = obj.Object
            'For Each obj As RhinoObject In myDoc.Objects.GetObjectList(settings)

            Dim myBox As BoundingBox = obj.Geometry.GetBoundingBox(False)

            If WorkBBox.Contains(myBox) Then

                ToolName = myDoc.Layers(myRhinoObj.Attributes.LayerIndex).GetUserString(ToolKey)

                Dim myToolGeometryObj As GeometryObject = RhToToolGeom(myRhinoObj, Device.ZeroPoint)

                Device.addPlotObject(ToolName, myToolGeometryObj)

            End If

        Next

        Return objectCount

    End Function

    Sub ProcessWithPreChoosenObjects(ByVal Device As CNC_Device, ByVal Conduit As rhDisplayConduit)

        If Not Device.isOptimized Then

            Optimizer.OptimizePathes(Device)

        End If

        nrObj = DisplayAllObjByTool(Device, Conduit)

        HideAllObjects()

        nrObj = DisplayAllObjByTool(Device, Conduit)

        If nrObj > 0 Then

            Device.Process()

        End If

        'PurgeConduit(Conduit)

        Conduit.Purge()

        Device.isOptimized = False

        ShowAllObjects()

    End Sub

    Sub PreviewOn(ByVal Device As CNC_Device, ByVal Conduit As rhDisplayConduit, ByVal withBBox As Boolean, ByVal BBoffset As Double)
        'delete all geometry objects
        PurgeOldObjectsFromTools(Device)
        'objekte einsammeln
        CollectingObjects(Device)
        'den pfad optimieren
        Optimizer.OptimizePathes(Device)
        'alle rhinoobjekte ausschalten
        HideAllObjects()

        'alle werkzeugpfade ins conduit
        nrObj = DisplayAllObjByTool(Device, Conduit)

        If withBBox AndAlso nrObj > 0 Then
            'die BBox holen
            BBoxOn(Device, Conduit, CDec(BBoffset))

        End If

        Device.currentObject = 0 'this will calculate the estimated jobtime

        UpdateLabel(Device, LabelState.Estimated)

    End Sub

    Sub PreviewOff(ByVal Conduit As rhDisplayConduit)
        'das cunduit leeren
        'PurgeConduit(Conduit)
        Conduit.Purge()

        LengtLabel.Text = ""
        'alle objekte die wir ausgeblendet haben wieder einblenden
        ShowAllObjects()

    End Sub

    Sub UpdatePath(ByVal Device As CNC_Device, ByVal Conduit As rhDisplayConduit)
        'den pfad optimieren
        Optimizer.OptimizePathes(Device)

        nrObj = DisplayAllObjByTool(Device, Conduit)
        'die Länge anzeigen und berechnungszeit anzeigen
        Device.currentObject = 0 'this will calculate the estimated jobtime

        UpdateLabel(Device, LabelState.Estimated)

    End Sub


End Class
